#pragma once

#include "DxPipeline.h"

bool compileFractal();