/*void funcInput(void* userData, LPARAM lp, WPARAM wp) {
	GuiWindow* g = (GuiWindow*) userData;

	UINT dwSize;

    GetRawInputData((HRAWINPUT)lp, RID_INPUT, NULL, &dwSize, sizeof(RAWINPUTHEADER));
    LPBYTE lpb = new BYTE[dwSize];
    if (lpb == NULL) return;

    if (GetRawInputData((HRAWINPUT)lp, RID_INPUT, lpb, &dwSize, sizeof(RAWINPUTHEADER)) != dwSize ) return;

    RAWINPUT* raw = (RAWINPUT*)lpb;

    if (raw->header.dwType == RIM_TYPEKEYBOARD) 
    {
		KeyEvent e;
		e.keyD = raw->data.keyboard.Flags & RI_KEY_MAKE;
		e.keyU = raw->data.keyboard.Flags & RI_KEY_BREAK;
		e.key = raw->data.keyboard.VKey;

		if(g->focusEle) {
			g->focusEle->onKey(e);
		}
    }
    else if (raw->header.dwType == RIM_TYPEMOUSE) 
    {
		g->mouseGlobal.butLeftD = raw->data.mouse.ulButtons & RI_MOUSE_LEFT_BUTTON_DOWN;
		g->mouseGlobal.butLeftU = raw->data.mouse.ulButtons & RI_MOUSE_LEFT_BUTTON_UP;
		g->mouseGlobal.butMidD = raw->data.mouse.ulButtons & RI_MOUSE_MIDDLE_BUTTON_DOWN;
		g->mouseGlobal.butMidU = raw->data.mouse.ulButtons & RI_MOUSE_MIDDLE_BUTTON_UP;
		g->mouseGlobal.butRightD = raw->data.mouse.ulButtons & RI_MOUSE_RIGHT_BUTTON_DOWN;
		g->mouseGlobal.butRightU = raw->data.mouse.ulButtons & RI_MOUSE_RIGHT_BUTTON_UP;

		if(raw->data.mouse.usFlags & MOUSE_MOVE_RELATIVE) {
			g->mouseGlobal.x += raw->data.mouse.lLastX;
			g->mouseGlobal.y += raw->data.mouse.lLastY;
		}
		if(raw->data.mouse.usFlags & MOUSE_MOVE_ABSOLUTE) {
			g->mouseGlobal.x = raw->data.mouse.lLastX;
			g->mouseGlobal.y = raw->data.mouse.lLastY;
		}
		printf("mouse: %04d, %04d\n",g->mouseGlobal.x,g->mouseGlobal.y);

		GuiElement* hover = NULL;
		for (GuiElement*& e : g->listElements) {
			if( (g->mouseGlobal.x > e->a.x && (g->mouseGlobal.x < (e->a.x + e->a.w)) ) && (g->mouseGlobal.y > e->a.y && (g->mouseGlobal.y < (e->a.y + e->a.w)) ) ) {
				hover = e;
			}
		}
		if(hover) { //we actually found an element we hover - and we choose the last one that we detected
			if(g->mouseEle != hover) { //we were something or nothing hovering before and now something else
				if(g->mouseEle) { //we were something hovering before
					g->mouseEle->onMouseLeave();
				}
				g->mouseEle = hover;
				g->mouseEle->onMouseEnter();
			} 
			if(g->mouseEle) { //we send the event to the element we are currently hovering
				MouseEvent mouseLocal = g->mouseGlobal;
				mouseLocal.x -= g->w->getX();
				mouseLocal.y -= g->w->getY();
				g->mouseEle->onMouse(mouseLocal);
			}
		}
		else { //we are not hovering anything
			if(g->mouseEle) { //we were hovering something before
				g->mouseEle->onMouseLeave();
			}
			g->mouseEle = NULL;
		}

		if(g->mouseGlobal.butLeftD ||  g->mouseGlobal.butRightD) { //focus into nirvana
			g->focusEle = g->mouseEle;
		}
    } 

    delete[] lpb;
}*/